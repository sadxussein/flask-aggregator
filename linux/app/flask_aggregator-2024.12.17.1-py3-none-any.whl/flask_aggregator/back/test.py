from flask_aggregator.back.elma_helper import ElmaHelper
from flask_aggregator.back.models import ElmaVM

def run():
    """External runner."""
    elma_helper = ElmaHelper()
    elma_helper.import_vm_list(ElmaVM, "/mnt/d/work/ElmaVMs.xlsx")

if __name__ == "__main__":
    run()
