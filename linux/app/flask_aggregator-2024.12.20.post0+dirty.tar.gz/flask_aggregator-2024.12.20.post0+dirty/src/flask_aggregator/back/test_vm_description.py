from flask_aggregator.back.ovirt_helper import OvirtHelper

def run():
    """External runner."""
    ovirt_helper = OvirtHelper(dpc_list=["e15-test2"])
    ovirt_helper.connect_to_virtualization()
    # ovirt_helper.clean_desc()
    ovirt_helper.set_vm_description()
    ovirt_helper.disconnect_from_virtualization()

if __name__ == "__main__":
    run()
