import pandas as pd

from flask_aggregator.config import Config as cfg
from flask_aggregator.back.dbmanager import DBManager
from flask_aggregator.back.elma_helper import ElmaHelper
from flask_aggregator.back.models import (
    VmsToBeBackedUpView, BackupsView, Storage
)
from flask_aggregator.back.controllers import (
    DBController,
    StorageView,
    GBTransformer,
    OvirtController,
    DataFrameView,
    TestTransformer
)
from flask_aggregator.back.virt_aggregator import VirtAggregator
from flask_aggregator.back.ovirt_helper import OvirtHelper

def get_elma_vm_access_doc() -> None:
    """Collect VmAccessDoc from elma API.
    
    Table with information about VM documents will be upserted to 
    `elma_vm_access_doc` table.
    """
    elma_helper = ElmaHelper()
    elma_helper.import_vm_access_doc()

def get_data_from_view() -> list:
    dbmanager = DBManager()
    count, data = dbmanager.get_data_from_view_test(VmsToBeBackedUpView)
    for el in data:
        with open("test.txt", 'a', encoding="utf-8") as file:
            print(el.as_line, file=file)
    print(count)

def create_views():
    dbmanager = DBManager()
    dbmanager.generate_views()

def get_data_from_controller():
    controller = DBController("storages")
    tf = GBTransformer()
    view = StorageView(transformers=[tf])
    display = view.update_view(controller.data)
    return display

def get_user_vms_list() -> list:
    va = OvirtHelper(dpc_list=["e15-test2"])
    va.connect_to_virtualization()
    result = va.get_user_vm_list()
    va.disconnect_from_virtualization()
    return result

def get_user_vms_list_via_controller() -> list:
    ovc = OvirtController(dpc_list=["e15-test2"])
    ovc.get_user_vm_list()
    ovc.save_user_vm_excel()
    return ovc.data

def get_user_vms_list_via_view() -> None:
    ovc = OvirtController(dpc_list=cfg.DPC_LIST)
    ovc.get_user_vm_list()
    ovtf = TestTransformer()
    ovvw = DataFrameView(transformers=[ovtf])
    data = ovvw.update_view(ovc.data)
    data.to_excel("/app/files/test.xlsx", index=False, engine="openpyxl")

def run():
    """External runner."""
    model = Model()
    view = View()
    controller = Controller(model, view)
    controller.render_data()
    data = [
        {
            "field1": "data1",
            "field2": "data2"
        },
        {
            "field1": "data3",
            "field2": "data4"
        }
    ]
    controller.update_data(data)
    controller.render_data()


if __name__ == "__main__":
    get_user_vms_list_via_view()
