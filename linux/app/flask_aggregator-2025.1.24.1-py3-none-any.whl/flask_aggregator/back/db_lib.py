"""Test module for database interactions architecture."""

from abc import ABC, abstractmethod

from sqlalchemy import create_engine, MetaData, Table
from sqlalchemy.orm import sessionmaker, scoped_session


class DBConnection():
    """Handles database connections via SQLAlchemy."""
    def __init__(self, db_url: str):
        self.__engine = create_engine(db_url)
        self.__session_factory = sessionmaker(bind=self.__engine)
        self.__ss = scoped_session(self.__session_factory)

    def get_engine(self):
        """Get engine for external client."""
        return self.__engine

    def get_session(self):
        """Simply return session for external client."""
        return self.__ss

    def close_session(self):
        """Close current session with DB."""
        self.__ss.remove()


class DBManager(ABC):
    """Abstract class for managing table/view creation."""
    def __init__(self, engine: any):
        self.__md = MetaData()
        self.__e = engine
        self.__ents = []

    # TODO: read about Alembic!
    def create_table(self, t: Table) -> None:
        """Create table/view in database."""
        self.__md.create_all(bind=self.__e, tables=[t])

    def create_all_tables(self) -> None:
        """Create all tables/views in database."""
        self.__md.create_all(bind=self.__e)

    def drop_table(self, t: Table) -> None:
        """Remove table/view from database."""
        self.__md.drop_all(bind=self.__e, tables=[t])

    def drop_all_tables(self) -> None:
        """Remove all tables/views from database."""
        self.__md.drop_all(bind=self.__e)


class DBRepository(ABC):
    """Abstract class for different variants of database interactions.
    
    Driver may vary.
    """
    def __init__(self, conn: DBConnection):
        self.__s = conn.get_session()

    @abstractmethod
    def get_all_data(self, model: any) -> list:
        """Return all rows from table."""

    @abstractmethod
    def get_filtered_data(self, model: any) -> list:
        """Return filtered data from table."""

    @abstractmethod
    def get_paginated_data(self, model: any) -> list:
        """Return paginated and filtered data from table."""

    @abstractmethod
    def set_data(self, model: any, data: list) -> None:
        """Replace current data in table."""

    @abstractmethod
    def upsert_data(
        self,
        model: any,
        data: list,
        index_elements: list,
        included_elements: list
    ) -> None:
        """Upsert/update data in table."""

class ReadOnlyPSQLManager(DBRepository):
    """Postgresql read-only manager."""
    def __init__(self, conn: DBConnection):
        super().__init__(conn)

    def get_all_data(self, table_name):
        return super().get_all_data(table_name)

    def get_filtered_data(self, table_name):
        return super().get_filtered_data(table_name)

    def get_paginated_data(self, table_name):
        return super().get_paginated_data(table_name)

    def set_data(self, table_name: str, data: list):
        pass
