"""Module for VZ (Rosplatforma) interactions."""

import ansible_runner

from flask_aggregator.back.virt_protocol import VirtProtocol

class VirtuozzoHelper(VirtProtocol):
    """Main helper class."""
    def __init__(self):
        pass

