"""Attempt to make full-scale view (MVC pattern)."""

