from flask_aggregator.back.dbmanager import DBManager
from flask_aggregator.back.elma_helper import ElmaHelper
from flask_aggregator.back.models import VmsToBeBackedUpView, BackupsView

def get_elma_vm_access_doc() -> None:
    """Collect VmAccessDoc from elma API.
    
    Table with information about VM documents will be upserted to 
    `elma_vm_access_doc` table.
    """
    elma_helper = ElmaHelper()
    elma_helper.import_vm_access_doc()

def get_data_from_view() -> list:
    dbmanager = DBManager()
    count, data = dbmanager.get_data_from_view(VmsToBeBackedUpView)
    for el in data:
        with open("test.txt", 'a', encoding="utf-8") as file:
            print(el.as_line, file=file)
    print(count)

def run():
    """External runner."""
    dbmanager = DBManager()

if __name__ == "__main__":
    # get_elma_vm_access_doc()
    get_data_from_view()
    # run()
