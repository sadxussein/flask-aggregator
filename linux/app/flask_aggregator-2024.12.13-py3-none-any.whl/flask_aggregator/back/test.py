from flask_aggregator.back.dbmanager import DBManager

def run():
    """External runner."""
    dbmanager = DBManager(env="dev")
    result = dbmanager.get_old_backups()
    for el in result:
        print(el.as_dict)
    # print(result[0].as_dict)
    print(len(result))

if __name__ == "__main__":
    run()
